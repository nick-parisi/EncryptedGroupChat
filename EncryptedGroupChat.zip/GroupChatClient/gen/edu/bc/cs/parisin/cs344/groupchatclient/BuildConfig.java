/** Automatically generated file. DO NOT MODIFY */
package edu.bc.cs.parisin.cs344.groupchatclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}